const transactions = [
    {transaction_id: 1, transaction_date: "24.12.2024", transaction_amount: 1249, transaction_type: "expense", transaction_description: "Flowers", merchant_name: "IubiDubi", card_type: "debit"},
    {transaction_id: 2, transaction_date: "1.02.2025", transaction_amount: 269, transaction_type: "expense", transaction_description: "Lunch", merchant_name: "Bulka", card_type: "credit"},
    {transaction_id: 3, transaction_date: "14.02.2025", transaction_amount: 4398, transaction_type: "expense", transaction_description: "Dinner", merchant_name: "Pegas", card_type: "debit"},
    {transaction_id: 4, transaction_date: "4.03.2025", transaction_amount: 40560, transaction_type: "revenue", transaction_description: "Salary", merchant_name: "Endava", card_type: "debit"},
    {transaction_id: 5, transaction_date: "8.03.2025", transaction_amount: 1400, transaction_type: "expense", transaction_description: "Gas_station", merchant_name: "Rompetrol", card_type: "debit"}
]

function getUniqueTransactionTypes(transactions) {
    return [...new Set(transactions.map(t => t.transaction_type))]
}

function calculateTotalAmount(transactions) {
    return transactions.reduce((sum, t) => sum + t.transaction_amount, 0)
}
//extra
function calculateTotalAmountByDate(transactions, day, month, year) {
    return transactions.filter(t => {
            const [transactionDay, transactionMonth, transactionYear] = t.transaction_date.split('.').map(num => parseInt(num));

                const matchesDay = day ? transactionDay === day : true;
                const matchesMonth = month ? transactionMonth === month : true;
                const matchesYear = year ? transactionYear === year : true;

            return matchesYear && matchesMonth && matchesDay;
        })
        .reduce((sum, t) => sum + t.transaction_amount, 0);
}

function getTransactionByType(transactions, type) {
    return transactions.filter(t => t.card_type === type)
}

function getTransactionsInDateRange(transactions, startDate, endDate) {
    return transactions.filter(t => t.transaction_date >= startDate && t.transaction_date <= endDate)
}

function getTransactionsByMerchant(transactions, merchantName) {
    return transactions.filter(t => t.merchant_name === merchantName)
}

function calculateAverageTransactionAmount(transactions) {
    if (transactions.length === 0) return 0;
    return transactions.reduce((sum, t) => sum + t.transaction_amount, 0) / transactions.length
}

function getTransactionsByAmountRange(transactions, minAmount, maxAmount) {
    return transactions.filter(t => t.transaction_date >= minAmount && t.transaction_date <= maxAmount)
}

function calculateTotalDebitAmount(transactions) {
        return transactions.filter(t => t.card_type === "debit").reduce((sum, t) => sum + t.transaction_amount, 0)

}

function findMostTransactionsMonth(transactions) {
    //return transactions.map(t => t.transaction_date.split('.'[1]).reduce((acc, month) => ((acc[month] = (acc[month] || 0)+1), acc),{}))
    const monthCounts = transactions.reduce((acc, t) => {
        const month = t.transaction_date.split('.')[1]
        acc[month] = (acc[month] || 0) + 1
        return acc
    }, {});
    return Object.keys(monthCounts).reduce((a, b) => monthCounts[a] > monthCounts[b] ? a : b)
}

function findMostDebitTransactionMonth(transactions) {
    return findMostTransactionsMonth(getTransactionByType(transactions, "debit"))
}

function mostTransactionTypes(transactions) {
    const creditCount = getTransactionByType(transactions, "credit").length;
    const debitCount = getTransactionByType(transactions, "debit").length;
        return creditCount > debitCount ? "credit" : debitCount > creditCount ? "debit" : "equal";
}

function getTransactionsBeforeDate(transactions, date) {
    return transactions.filter(t => t.transaction_date < date)
}

function findTransactionById(transactions, id) {
    return transactions.filter(t => t.transaction_id === id)
}

function mapTransactionDescriptions(transactions) {
    return transactions.map(t => t.transaction_description)
}

console.log (getUniqueTransactionTypes(transactions))
console.log (calculateTotalAmount(transactions))
console.log (getTransactionByType(transactions, "credit"))
console.log(getTransactionsInDateRange(transactions,"14.12.2025","8.03.2025"))
console.log(getTransactionsByMerchant(transactions, "Rompetrol"))
console.log(calculateAverageTransactionAmount(transactions))
console.log(getTransactionsByAmountRange(transactions,100, 5000))
console.log(calculateTotalDebitAmount(transactions))
console.log(findMostTransactionsMonth(transactions))
console.log(findMostDebitTransactionMonth(transactions))
console.log(mostTransactionTypes(transactions))
console.log(getTransactionsBeforeDate(transactions, "4.03.2025"))
console.log(findTransactionById(transactions, 4))
console.log(mapTransactionDescriptions(transactions))

//extra
console.log(calculateTotalAmountByDate(transactions, 14, 3, 2024));